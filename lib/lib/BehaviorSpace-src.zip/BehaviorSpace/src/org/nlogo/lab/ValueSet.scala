// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab

abstract class ValueSet(val variableName: String)
  extends IterableProxy[Any]

class EnumeratedValueSet(variableName: String,
                         values: List[Any])
  extends ValueSet(variableName)
{
  def self = values
}

class SteppedValueSet(variableName: String,
                      val first: Double,
                      val step: Double,
                      val last: Double)
  extends ValueSet(variableName)
{
  def self = Stream.from(0)
                   .map(first + step * _)
                   .takeWhile(_ <= last)
                   .map(java.lang.Double.valueOf(_))
}
