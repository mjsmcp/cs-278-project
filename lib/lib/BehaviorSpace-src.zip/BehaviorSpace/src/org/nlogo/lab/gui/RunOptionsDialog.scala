// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab.gui

import org.nlogo.api.{Editable,PropertyDescription}
import org.nlogo.awt.UserCancelException
import org.nlogo.window.EditDialogFactoryInterface
import java.awt.GridBagConstraints
import Supervisor.RunOptions

class RunOptionsDialog(parent: java.awt.Dialog,
                       dialogFactory: EditDialogFactoryInterface)
{
  def get = {
    val editable = new EditableRunOptions
    if(dialogFactory.canceled(parent, editable, false, null, null))
      throw new UserCancelException
    editable.get
  }
  class EditableRunOptions extends Editable {
    var spreadsheet = true
    var table = false
    var threadCount = Runtime.getRuntime.availableProcessors
    val classDisplayName = "Run options"
    import org.nlogo.util.JCL.seqToJavaList
    val propertySet:java.util.List[PropertyDescription] = List(
      new PropertyDescription("spreadsheet", "Spreadsheet output",
                              "Boolean", GridBagConstraints.REMAINDER, true),
      new PropertyDescription("table","Table output",
                              "Boolean", GridBagConstraints.REMAINDER, false),
      new PropertyDescription("threadCount","Simultaneous runs in parallel",
                              "<html>If more than one, some runs happen invisibly in the background." +
                              "<br>Defaults to one per processor core.</html>",
                              "Integer", GridBagConstraints.REMAINDER, false))
    def get = RunOptions(threadCount, table, spreadsheet)
    // boilerplate for Editable
    val error = null
    val errorProperty = null
    val sourceOffset = 0
    def editFinished = true
  }
}
