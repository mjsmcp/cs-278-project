// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab.gui

import org.junit.runner.RunWith
import org.junit.runners.Suite
import org.junit.runners.Suite.SuiteClasses

@RunWith(classOf[Suite])
@SuiteClasses(Array(classOf[TestProtocolEditable]))
class AllTests
