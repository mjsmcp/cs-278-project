// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab.gui

import org.nlogo.api.Dump
import org.nlogo.plot.PlotPen
import org.nlogo.window.{PlotWidget,ViewUpdatePanel}
import org.nlogo.nvm.{LabInterface,Workspace}
import LabInterface.ProgressListener

// Throughout this file, we say "plotWidget.plot()" instead of just "plotWidget.plot"
// because otherwise it fails with an IllegalAccessException as of Scala 2.7.2.RC6.
// https://lampsvn.epfl.ch/trac/scala/ticket/1240 - ST 10/30/08

private [gui] class ProgressDialog(dialog: java.awt.Dialog,
                                   supervisor: Supervisor)
              extends javax.swing.JDialog(dialog, true) with ProgressListener
{
  private val totalRuns =
    supervisor.worker.protocol.countRuns
  private val progressArea =
    new javax.swing.JTextArea(10 min (supervisor.worker.protocol.valueSets.size + 3), 0)
  private val timer =
    new javax.swing.Timer(
      org.nlogo.nvm.JobManagerInterface.PERIODIC_UPDATE_DELAY,
      periodicUpdateAction)
  private var plotWidget: PlotWidget = null

  // put initialization stuff in a block so local vals stay local
  {
    setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE)
    addWindowListener(new java.awt.event.WindowAdapter {
      override def windowClosing(e: java.awt.event.WindowEvent) {
        abortAction.actionPerformed(null) } })
    setTitle("Running Experiment: " + supervisor.worker.protocol.name)
    setResizable(true)
    val layout = new java.awt.GridBagLayout
    getContentPane.setLayout(layout)
    val c = new java.awt.GridBagConstraints
    c.gridwidth = java.awt.GridBagConstraints.REMAINDER
    c.fill = java.awt.GridBagConstraints.BOTH
    c.weightx = 1.0
    c.weighty = 0.0
    c.insets = new java.awt.Insets(6, 6, 0, 6)
    val ticksPanel = new ViewUpdatePanel(
      supervisor.workspace,
      new org.nlogo.window.DisplaySwitch(supervisor.workspace),
      false)
    layout.setConstraints(ticksPanel, c)
    getContentPane.add(ticksPanel)
    c.weighty = 1.0
    if(supervisor.worker.protocol.runMetricsEveryStep &&
       supervisor.worker.protocol.metrics.length > 0)
    {
      plotWidget = new org.nlogo.window.PlotWidget("Behavior Plot")
      plotWidget.plot().defaultXMin(0)
      plotWidget.plot().defaultYMin(0)
      plotWidget.plot().defaultXMax(1)
      plotWidget.plot().defaultYMax(1)
      plotWidget.plot().defaultAutoPlotOn(true)
      plotWidget.xLabel("Time")
      plotWidget.yLabel("Behavior")
      plotWidget.clear()
      plotWidget.togglePenList()
      layout.setConstraints(plotWidget, c)
      getContentPane.add(plotWidget)
    }
    else plotWidget = null
    progressArea.setEditable(false)
    progressArea.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 5, 5, 5))
    val scrollPane =
      new javax.swing.JScrollPane(
        progressArea,
        javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
        javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED)
    layout.setConstraints(scrollPane, c)
    getContentPane.add(scrollPane)
    updateProgressArea(true)
    scrollPane.setMinimumSize(scrollPane.getPreferredSize())

    c.weighty = 0.0
    val displaySwitch = new javax.swing.JCheckBox(displaySwitchAction)
    displaySwitch.setSelected(true)
    supervisor.workspace.displaySwitchOn(true)
    c.fill = java.awt.GridBagConstraints.HORIZONTAL
    layout.setConstraints(displaySwitch, c)
    getContentPane.add(displaySwitch)

    val plotsAndMonitorsSwitch = new javax.swing.JCheckBox(plotsAndMonitorsSwitchAction)
    plotsAndMonitorsSwitch.setSelected(true)
    c.insets = new java.awt.Insets(0, 6, 0, 6)
    layout.setConstraints(plotsAndMonitorsSwitch, c)
    getContentPane.add(plotsAndMonitorsSwitch)

    val abortButton = new javax.swing.JButton(abortAction)
    c.fill = java.awt.GridBagConstraints.NONE
    c.anchor = java.awt.GridBagConstraints.EAST
    c.insets = new java.awt.Insets(6, 6, 6, 6)
    layout.setConstraints(abortButton, c)
    getContentPane.add(abortButton)

    timer.start()

    pack()
    org.nlogo.awt.Utils.center(this, dialog)
  }
        
  override def getMinimumSize = getPreferredSize
  override def getPreferredSize =
    new java.awt.Dimension(
      super.getPreferredSize.width max 450,
      super.getPreferredSize.height)

  // The following actions are declared lazy so we can use them in the
  // initialization code above.  Two cheers for Scala. - ST 11/12/08

  lazy val abortAction = new javax.swing.AbstractAction("Abort") {
    def actionPerformed(e: java.awt.event.ActionEvent) {
      supervisor.interrupt()
      close()
    } }
  lazy val periodicUpdateAction = new javax.swing.AbstractAction("update elapsed time") {
    def actionPerformed(e: java.awt.event.ActionEvent) {
      updateProgressArea(false)
      if(updatePlots && plotWidget != null) plotWidget.handle(null)
    } }
  lazy val displaySwitchAction = new javax.swing.AbstractAction("Update view") {
    def actionPerformed(e: java.awt.event.ActionEvent) {
      supervisor.workspace.displaySwitchOn(e.getSource.asInstanceOf[javax.swing.JCheckBox].isSelected)
    } }
  lazy val plotsAndMonitorsSwitchAction = new javax.swing.AbstractAction("Update plots and monitors") {
    def actionPerformed(e: java.awt.event.ActionEvent) {
      updatePlots = e.getSource.asInstanceOf[javax.swing.JCheckBox].isSelected
      if(updatePlots) supervisor.workspace.setPeriodicUpdatesEnabled(true)
      else {
        supervisor.workspace.setPeriodicUpdatesEnabled(false)
        supervisor.workspace.jobManager.finishSecondaryJobs(null)
      }
    } }
  def close() {
    timer.stop()
    setVisible(false)
    dispose()
    supervisor.workspace.displaySwitchOn(true)
    supervisor.workspace.setPeriodicUpdatesEnabled(true)
  }

  /// ProgressListener implementation

  private var updatePlots = true
  private var started = 0L
  private var runCount = 0
  private var elapsed = "0:00:00"
  private var settingsString = ""
  private var steps = 0

  override def experimentStarted() { started = System.currentTimeMillis }
  override def runStarted(w: Workspace, runNumber: Int, settings: List[Pair[String,Any]]) {
    if(!w.isHeadless) {
      runCount = runNumber
      steps = 0
      resetPlot()
      settingsString = ""
      for((name, value) <- settings)
        settingsString += name + " = " + Dump.logoObject(value) + "\n"
      updateProgressArea(true)
    }
  }
  override def stepCompleted(w: Workspace, steps: Int) {
    if(!w.isHeadless) this.steps = steps
  }
  override def measurementsTaken(w: Workspace, runNumber: Int, step: Int, values: List[AnyRef]) {
    if(!w.isHeadless) plotNextPoint(values)
  }
  private def resetPlot() {
    if(plotWidget == null) return
    try {
      org.nlogo.awt.Utils.invokeAndWait(
        new Runnable { def run() {
          plotWidget.clear()
          for(metricNumber <- 0 until supervisor.worker.protocol.metrics.length) {
            // kludginess here because plots really, really want to always have a default pen - ST 1/18/09
            val pen = if(metricNumber == 0) plotWidget.plot().currentPen
                      else new PlotPen(plotWidget.plot(), getPenName(metricNumber), true)
            if(metricNumber == 0) {
              pen.name(getPenName(0))
              plotWidget.plot().pens.clear()
              plotWidget.plot().pens.addPen(pen)
            }
            pen.color(org.nlogo.api.Color.getColor(java.lang.Double.valueOf(metricNumber % 14 * 10 + 5)).getRGB)
          } } } ) }
    catch{ case ex: InterruptedException =>
            // we may get interrupted if the user aborts the run - ST 10/30/03
            org.nlogo.util.Exceptions.ignore(ex) }
  }
  private def getPenName(metricNumber: Int): String = {
    val buf = new StringBuilder()
    if(supervisor.worker.protocol.metrics.length > 1)
      buf.append(metricNumber + " ")
    buf.append(org.nlogo.awt.Utils.shortenStringToFit(
      supervisor.worker.protocol.metrics(metricNumber).trim.replaceAll("\\s+", " "),
      100, // an arbitrary limit to keep the pen names from getting too wide
      plotWidget.getFontMetrics(plotWidget.getFont)))
    buf.toString
  }
  private def plotNextPoint(measurements: List[AnyRef]) {
    if(plotWidget == null) return
    try {
      org.nlogo.awt.Utils.invokeAndWait(
        new Runnable { def run() {
          for(metricNumber <- 0 until supervisor.worker.protocol.metrics.length) {
            val measurement = measurements(metricNumber)
            if(measurement.isInstanceOf[Number]) {
              val pen = plotWidget.plot().pens.getPen(getPenName(metricNumber))
              pen.plot(steps, measurement.asInstanceOf[java.lang.Double].doubleValue)
            }
          }
          plotWidget.plot().makeDirty()
        } } )
    }
    catch{ case ex: InterruptedException =>
             // we may get interrupted if the user aborts the run - ST 10/30/03
             org.nlogo.util.Exceptions.ignore(ex) }
  }
  private def updateProgressArea(force: Boolean) {
    def pad(s: String) = if(s.length == 1) ("0" + s) else s
    val elapsedMillis: Int = ((System.currentTimeMillis - started) / 1000).toInt
    val hours = (elapsedMillis / 3600).toString
    val minutes = pad(((elapsedMillis % 3600) / 60).toString)
    val seconds = pad((elapsedMillis % 60).toString)
    val newElapsed = hours + ":" + minutes + ":" + seconds
    if(force || elapsed != newElapsed) {
      elapsed = newElapsed
      org.nlogo.awt.Utils.invokeLater( new Runnable { def run() {
        progressArea.setText("Run #" + runCount + " of " + totalRuns + ", " +
                             "step #" + steps + "\n" +
                             "Total elapsed time: " + elapsed + "\n" + settingsString)
        progressArea.setCaretPosition(0)
      } } )
    }
  }
}
